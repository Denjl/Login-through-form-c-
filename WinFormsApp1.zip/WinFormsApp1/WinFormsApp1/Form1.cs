using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using Microsoft.Data.SqlClient;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        SqlConnection conn = new SqlConnection(@"Data Source=DESKTOP-9JO6LFV;Initial Catalog=Timovy;Integrated Security=True;Trusted_Connection=true;encrypt=false");



        private void label1_Click(object sender, EventArgs e)
        {


        }

        

        private void button1_Click_1(object sender, EventArgs e)
        {
            String user_name, pass_word;

            user_name = textBox1.Text;
            pass_word = textBox2.Text;

            Console.WriteLine("sdsadsad");

            try
            {
                String querry = "SELECT * FROM Login_new WHERE username = '"+textBox1.Text+"' AND password = '"+textBox2.Text+"'";
                //String querry = "SELECT * FROM Login_new WHERE username ='admin'";
                Console.WriteLine( querry);
                Console.WriteLine("sdsadsad");



                SqlDataAdapter sda = new SqlDataAdapter(querry, conn);

                DataTable dataTable = new DataTable();
                sda.Fill(dataTable);

                Console.WriteLine("sdsadsad");
                Console.WriteLine("sdsadsad");

                if (dataTable.Rows.Count > 0)
                {
                    user_name = textBox1.Text;
                    pass_word = textBox2.Text;


                    Menu form2 = new Menu();
                    form2.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Invalid login details", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    textBox1.Clear();
                    textBox2.Clear();
                }
            }
            catch
            {
                MessageBox.Show("Error");
            } 

            finally
            {
                conn.Close();
            }
        }
    }
}